#ifndef COUNTER_H_
#define COUNTER_H_

class MyCounter {
private:
        int value;
public:
        MyCounter();
        MyCounter(int );
        void increment();
        void reset();
        int getValue();
        bool equals (MyCounter );
        void print();

};

#endif // !COUNTER_H_

