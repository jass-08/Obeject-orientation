 //-----------------------------------------
     // NAME		: your name 
     // STUDENT NUMBER	: your student number
     // COURSE		: COMP 2150
     // INSTRUCTOR	: your instructor
     // ASSIGNMENT	: assignment #
     // QUESTION	: question #      
     // 
     // REMARKS: What is the purpose of this program?
     //
     //
     //-----------------------------------------
class Hashable{
    constructor(){
        if(this.constructor==Hashable){
            throw new Error("Can't use the abstract constructure");
        }else{
           
            
        }
    }
    //------------------------------------------------------
     //hashVal()
     // PURPOSE://the method finds the hasValue of the given parameter 
     //according to their type
     // PARAMETERS:
     //    int or String will output their respected hashVal
     //     0 will throw an error
     // Returns: returns the hashVal
     //------------------------------------------------------
    hashVal(){
        let result=0;
        if(arguments.length==1){
            if( typeof(arguments[0])==='number'){
                this.hashVal=arguments[0];
            }
            if(typeof arguments[0] === "string") {
            let p=13;
            for( let i=0;i<arguments[0].length;i++){
                result+=arguments[0].charCodeAt(i)*Math.pow(p,arguments[0].length-i-1);
                }
            }
        }
        else{
            throw new Error("Error in abstract  hashVal method");
        }
    this.hashVal= result;
    return this.hashVal;
    }
//this method checks if two given Hashable keys are equal
    equals(){//there must be two params or it will throw an arror that its abstract
        let result=false;
        if(arguments.length==2){
            if( typeof(arguments[0].hashVal)==='number'&& typeof(arguments[1].hashVal)==='number' ){
                if(arguments[0].hashVal==arguments[1].hashVal){
                    result=true;
                }
            }
        }else{
            throw new Error("Error in abstract equals method");
        }
        return result;

    }
}
//Two subclasses of the Hashable
class intHash extends Hashable{
    constructor(int) { 
        super();
        super.hashVal(int);
    }
}
class StringHash extends Hashable{
    constructor(String) { 
        super();
        super.hashVal(String);
    }
}
module.exports = Hashable;
module.exports = intHash;
module.exports = StringHash;