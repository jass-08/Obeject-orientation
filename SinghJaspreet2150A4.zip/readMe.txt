Good Morning/Evening

The program and test works fine, It just outputs the the encoded file to the console. Please run the HuffmanEncoding.js file for the trees

Also, for the test, please run the test file it should assert everything to true.

Thank you
Jaspreet Singh