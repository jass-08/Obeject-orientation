Hi there,

The assignment runs fine as given; just the following notes to be considered

*Answering the guess means can show a Card from the guess
* I am asking all the players for canAnswer not just one
* If the Human player can answer the guess please enter Y for Yes first; then Name of the Card and then type of the Card
* You must enter correct spelling of the card; Game would take it as guess and no other Player would give you the answer
*For Test 7 it will ask for input 
Please enter Y; then Jass; then Suspect exactly 
then
Please enter Y; then School;then Location exactly 
and it should pass

this represents that if we either enter Jass or school from the input for Guess 2 which is Jass, school and poison

And 

Following are the command to run the Game
1) javac Main.java
2) java Main

Following are the commands to run the tests:
 1) Computer.java
2) javac -cp .:junit-platform-console-standalone-1.6.0.jar ComputerTest.java
3) java -jar junit-platform-console-standalone-1.6.0.jar --class-path . --scan-class-path