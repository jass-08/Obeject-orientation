 //-----------------------------------------
     // NAME		: Jaspreet Singh 
     // STUDENT NUMBER	: 7859706
     // COURSE		: COMP 2150
     // INSTRUCTOR	: Micheal Domaratski
     // ASSIGNMENT	: assignment 4
     // REMARKS: To create a class for object named Dictionary 
//-----------------------------------------------
"use strict";
let ListNode=require('./LinkedList.js')
let Hashable=require('./Hashable.js')
class Dictionary {
    constructor() { 
        if(arguments.length=1 && typeof arguments[0]==='number'){
        this.size = arguments[0];
        this.array=new Array(this.size);
        }
    }
    //------------------------------------------------------
     //put(k,v)
     // PURPOSE://this function puts the key value pair in their appropriate location in 
     // the dictionary
     // PARAMETERS:
     //    Hashable k and Value v
     // Returns: no return value
     //------------------------------------------------------
    put(k,v){
        if(k instanceof Hashable){
            let result= hashVal(k)%this.size;
            let node=new ListNode(k,v);
            let top= array[result];
            node.next=null;
            if(array[result]==null){
                array[result]=node;
                node.next=null;
            }else{
                while(top.next!=null){
                    top=top.next;
                }
                top.next=node;
                top.next.next=null;
            }
        }
    }
    get(k){
        let result;
        if(k instanceof Hashable){
            result=array[hashVal(k)%this.size];
        }
        return result.value;
    }
    contains(k){
        let final =false;
        if(k instanceof Hashable){
            let result= hashVal(k)%this.size;
            if(this.array[result]!=null){
                final =false;
            }
        }
        return final;
    }
    isEmpty(){
        let result=true;
        for(let i=0;i<this.size;i++){
            if(this.array[i]!=null){
                result=false;
            }
        }
        return result;
    }
}
module.exports = Dictionary;
