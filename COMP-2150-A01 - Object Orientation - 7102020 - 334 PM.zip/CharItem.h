
#ifndef CHARITEM_H_
#define CHARITEM_H_

#include "ListItem.h"

class CharItem : public ListItem {
private:
	char data;
public:
	CharItem();
	CharItem(char i);
};

#endif

