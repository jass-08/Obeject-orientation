
public class Phone {

    private String phoneNumber;
    private String OS;
    private double screensize;

    public Phone(String phoneNumber, String OS, double screensize) {
        this.phoneNumber = phoneNumber;
        this.OS = OS;
        this.screensize = screensize;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getOS() {
        return OS;
    }

    public double getScreensize() {
        return screensize;
    }

    public void upgradeOS(String newOS) {
        this.os = newOS;
    }
}


