
#ifndef INTITEM_H_
#define INTITEM_H_

// what includes do we need?
// nothing!


class IntItem {
private:
	int data;
public:
	IntItem();
	IntItem(int i);
	void print();
};

#endif
 