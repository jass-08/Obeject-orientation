public class Main {

    public static void main(String[] args) {

        Furniture f1, f2;
        f1 = new Furniture();
        Chair c1,c2;
        c1 = new Chair();

        f2 = c1; // ok.
        // c2 = f1; -- not ok.

        c1.store(); 
        f1.store(); 
        f2.store(); 

        c1.sit(); 
        // f1.sit(); -- not ok.
        // f2.sit(); -- not ok.

        if (f2 instanceof Chair) {
            Chair newChair = (Chair) f2;
            newChair.sit();
        }

        // Chair c = (Chair) f1; -this doesn't make sense, since f1 is not a Chair.

    }
}

class Furniture {
    public Furniture() { }
    public void store() { System.out.println("storing furniture"); }
}

class Chair extends Furniture {
    public Chair() { }
    public void store() { System.out.println("storing chair");  }
    public void sit() { System.out.println("sitting on a chair."); }
}
