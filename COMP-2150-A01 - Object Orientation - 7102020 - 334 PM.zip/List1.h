#ifndef LIST_H_
#define LIST_H_

class Node;
class ListItem;

class List {
private:
	Node* head;
public:
	List();
	void print();
	void insert(ListItem*);
};

#endif /* LIST_H_ */
