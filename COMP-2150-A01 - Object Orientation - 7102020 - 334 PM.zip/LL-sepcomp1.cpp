
#include <iostream>

#include "List.h"
#include "IntItem.h"
 

int main() {
	List ll;
	IntItem item1(3);
	IntItem item2(5);

	ll.insert(&item1);
	ll.insert(&item2);

	ll.print();

	return 0;
}


