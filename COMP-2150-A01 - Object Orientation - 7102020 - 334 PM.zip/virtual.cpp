
#include <iostream>
using namespace std;

class Parent {
public:
	virtual void virt() { cout << "in Parent::virtualmethod" << endl; }
	void nonvirt() { cout << "in Parent::nonvirtual()" << endl; }
};

class Child : public Parent {
public:
	void vert() override { cout << "in Child::virtualmethod" << endl; }
	void nonvirt() { cout << "in Child::nonvirtual()" << endl; }
};

class GrandChild : public Child {
public:
	virtual void virt() { cout << "in GrandChild::virtualmethod" << endl; }
};


int main() {

	Parent* p = new Parent;
	p->virt();
	p->nonvirt();

	cout << "child instance, parent var" << endl;
	p = new Child;
	p->virt();
	p->nonvirt();

	cout << "child instance, child var" << endl;
	Child* c = new Child;
	c->nonvirt();

	// stack based objects.

	cout << "stack based" << endl;
	Parent ps;
	ps.virt();
	ps.nonvirt();

	Child cs;
	ps = cs;
	cout << "child instance, parent var" << endl;
	ps.virt();
	ps.nonvirt();

	// really weird case.
	Parent *gc = new GrandChild();
	gc->virt();
	return 0;
}

