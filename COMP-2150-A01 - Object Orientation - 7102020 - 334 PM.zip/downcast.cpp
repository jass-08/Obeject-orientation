#include <iostream>
using namespace std;

class Parent {
public:
	virtual void virt() { cout << "in Parent::virtualmethod" << endl; }
	void nonvirt() { cout << "in Parent::nonvirtual()" << endl; }
};

class Child1 : public Parent {
public:
	virtual void virt() { cout << "in Child::virtualmethod" << endl; }
	void nonvirt() { cout << "in Child::nonvirtual()" << endl; }
	void uniq() { cout << "in Child1::uniq()" << endl; }
};

class Child2 : public Parent {
public:
	virtual void virt() { cout << "in Child::virtualmethod" << endl; }
	void nonvirt() { cout << "in Child::nonvirtual()" << endl; }
	void uniq() { cout << "in Child2::uniq()" << endl; }
};


int main() {

	Parent* p = new Child1;

	Child1* c1 = dynamic_cast<Child1*>(p);
	Child2* c2 = dynamic_cast<Child2*>(p);

	if (c2==nullptr) {
		cout << "true." << endl;
	}

	if (c1 != nullptr) {
		c1->uniq();
	}
	return 0;
}


