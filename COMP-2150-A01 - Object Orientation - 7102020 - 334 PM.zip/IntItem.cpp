// what includes do we need?
#include "IntItem.h"

#include <iostream>
using namespace std;


IntItem::IntItem() {
	data = 0;
}

IntItem::IntItem(int i ) {
	data = i;
}

void IntItem::print() {
	cout << " " << data << " " ;
}

