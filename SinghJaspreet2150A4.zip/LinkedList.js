
 //-----------------------------------------
     // NAME		: Jaspreet Singh 
     // STUDENT NUMBER	: 7859706
     // COURSE		: COMP 2150
     // INSTRUCTOR	: Micheal Domaratski
     // ASSIGNMENT	: assignment 4
     // REMARKS: To create a class for object named ListNode for dictionary
//-----------------------------------------------
     class ListNode {
    constructor(k,v) {
        this.data = new({k:v})
        this.next = null                
    }
}
