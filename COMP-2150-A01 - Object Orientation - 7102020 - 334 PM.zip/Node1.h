#ifndef NODE_H_
#define NODE_H_

class ListItem;

class Node {
private:
	ListItem* item;
	Node* next;

public:
	Node();
	Node(ListItem*);
	void print();
 	Node* getNext();
	void setNext(Node*);
	ListItem* getData();
};

#endif
