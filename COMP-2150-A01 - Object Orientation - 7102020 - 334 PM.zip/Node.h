#ifndef NODE_H_
#define NODE_H_

// what #includes?
//#include "IntItem.h"
class IntItem;

class Node {
private:
	IntItem* item;
	Node* next;

public:
	Node();
	Node(IntItem*);
	void print();
 	Node* getNext();
	void setNext(Node*);
	IntItem* getData();
};

#endif /* NODE_H_ */

