
#include "MyCounter.h"

int main() {

	MyCounter m(9001);
	m.increment();
	m.increment();

	m.print();

}

