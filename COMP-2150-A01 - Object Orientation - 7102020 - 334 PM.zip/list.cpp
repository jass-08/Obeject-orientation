#include <iostream>
using namespace std;
 
class Node {
private:
  int data;
  Node* next;
public:
  Node* getNext();
  void setNext(Node* next);
  int getData();
  void print();
  Node(int data);
  Node();
};
 
class List {
private:
  Node* head;
public:
  void insert(int item);
  bool search (int item);
  void print();
  List();
};

// implementation starts here. 
//implementation of the methods of NODE class 
//YourOutPutType YourClassName :: YourMethodName(input parametrs) { implementation of your method} 

Node* Node::getNext() { return next; }
void Node::setNext(Node* next) { this->next = next; }
int Node::getData() { return data;}
void Node::print() { cout << data; }
Node::Node(int data) { this->data = data; this->next = nullptr;}
Node::Node () { this->data = 0;  this->next = nullptr;}
 


//implementation of the methods of List class 
List::List() { head = nullptr; }
void List::print() {
  Node* currNode = head;
  cout << "The list contains: ";
  while (currNode != nullptr ) {
    currNode->print();
    cout << " ";
    currNode = currNode->getNext();
  }
  cout << endl;
}
 
void List::insert(int item) {
  Node* newNode = new Node(item);
  newNode->setNext(head);
  head = newNode;
}

bool List::search(int item) {
  bool found = false;
  Node* currNode = head;
  while ( currNode != nullptr && !found) {
    found = (currNode->getData() == item);
    currNode=currNode->getNext();
  }
  return found;
}

int main(void) {
  List* l =new List;

  // add some stuff, print some stuff, search for some stuff. 
}

