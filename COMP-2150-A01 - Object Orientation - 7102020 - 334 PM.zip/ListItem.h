#ifndef LISTITEM_H_
#define LISTITEM_H_

class ListItem {
public:
	virtual void print() = 0;
	void dostuff();
};

#endif

