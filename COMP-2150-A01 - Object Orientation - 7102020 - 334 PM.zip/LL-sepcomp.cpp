
#include <iostream>

// what includes do we need?
#include "List.h"
#include "IntItem.h"

int main() {
	List* ll = new List();
	IntItem* item1 = new IntItem(3);
	IntItem* item2 = new IntItem(5);

	ll->insert(item1);
	ll->insert(item2);
	ll->print();

	return 0;
}


