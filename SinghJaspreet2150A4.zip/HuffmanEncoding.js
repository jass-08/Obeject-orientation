
 //-----------------------------------------
     // NAME		: Jaspreet Singh 
     // STUDENT NUMBER	: 7859706
     // COURSE		: COMP 2150
     // INSTRUCTOR	: Micheal Domaratski
     // ASSIGNMENT	: assignment 4
     // REMARKS: To create a class for HuffmanEncoding and compression for a given text file
//-----------------------------------------------
"use strict";
let fs=require('fs');
const Tree = require('./HuffmanTree.js');
let Node=require('./Node.js')
class HuffmanEncoding{
    constructor(){
    }
}
//------------------------------------------------------
     //encode()
     // PURPOSE:This function reads the hamlet file and, first
     // initializes all the chars and calculates their respected wieghts
     // PARAMETERS:
     //    no params
     // Returns: no return just prints out the Tree
     //------------------------------------------------------
function encode(file){
    let array=readFile(file);
    let array2=new Array(0);
    let T=new Tree("",0);
    //for loop to initialize trees for all the chars
    for(let i=0;i<array.length;i++){
        let tree=new Tree(array[i].char,array[i].wieght);
        array2.push(tree);
        
    }
    console.log(array2);
    while(array2.length>0){
        let w=lowest2(array2);
        T.add(w[0],w[1]);
        remove(w[0],w[1],array2);
        console.log(w[1]);
    }
    console.log(array2);
}
//this function reads the file at once and calculates the respective frequencies
function readFile(file){
    let arr=new Array(0);
    let contents = fs.readFileSync(file,"utf8");
    let chars=contents.split("");
    //for loop to store frequencies and chars
    
    for(let i=0;i<chars.length;i++){
        if(constains(arr,chars[i])){//if our arr contains the char already
            let result=getIndex(arr,chars[i]);
            arr[result].wieght++;
        }else{
            let element=new Node(chars[i],1);
            // console.log(element);
            arr.push(element);
        }
    }
    getFrequency(arr,chars.length);
    return arr;
}
//this function returns true if the array contains the given element
function constains(array, element){
    let result=false;
    for(let i=0;i<array.length;i++){
        if(array[i].char==element){
            result=true;
        }
    }
    return result;
}
//this method returns index location of the given element(Node) in the array
//this method must be run after conatins is true
function getIndex(array, element){
    let result=-1;
    for(let i=0;i<array.length;i++){
        if(array[i].char==element){
            result=i;
        }
    }
    return result;
}
//this function changes the wieght of each char into 0 to 1 given total number of chards
function getFrequency(array,total){
    for(let i=0;i<array.length;i++){
        array[i].wieght=array[i].wieght/total;
    }
}
//------------------------------------------------------
     //HuffmanEndoding
     // PURPOSE://this function finds the lowest two elements in the given array
     // PARAMETERS:
     //    an array of type tree
     // Returns: returns the array of two least elemets
     //------------------------------------------------------

function lowest2(array){
    let l1=new Tree("",1);//lowest
    let l2=new Tree("",1);//second lowest
    for(let i=0;i<array.length;i++){
        if(array[i].node.wieght<l1.node.wieght && array[i] instanceof Tree){//to check if the element is really a tree
            l2.node.wieght=l1.node.wieght;
            l1.node.wieght=array[i].node.wieght;
        }else if(array[i].node.wieght<l2.node.wieght&& array[i].node.wieght>l1.node.wieght){
            l2.node.wieght=array[i].node.wieght;
        }
    }
    return [l1,l2];
}
// this function removes the given two elements from the array
function remove(a,b,array){
    for(let i=0;i<array.length;i++){
        if(array[i].node.wieght==a.node.wieght||array[i].node.wieght==b.node.wieght ){
            array.splice(i,1);
        }
    }
}
encode("hamlet.txt");