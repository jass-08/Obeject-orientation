#include "Node.h"
#include "ListItem.h"

Node* Node::getNext() { 
	return next; 
}

void Node::setNext(Node* next) { 
	this->next = next; 
}

ListItem* Node::getData() {
	return item;
}

void Node::print() { 
	item->print();
}

Node::Node(ListItem* item) {
	this->item = item; 
	this->next = nullptr;
}

Node::Node() {
	this->item = 0; 
	this->next = nullptr;
}
