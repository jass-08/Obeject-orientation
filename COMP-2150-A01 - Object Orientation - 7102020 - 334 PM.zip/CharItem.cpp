
#include "CharItem.h"

CharItem::CharItem() {
	data = (char) 0;
}

CharItem::CharItem(char c) {
	data = c;
}

