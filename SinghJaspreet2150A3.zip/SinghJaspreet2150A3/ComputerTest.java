// CLASS: ComputerTest.java
//
// Author: Jaspreet Singh,7859706
//
// REMARKS: The purpose of this class is to test the implementation Human and Computer.java
// such that they both makes a reasonable choices as the
//the game progress
//It contains 7 separate tests each is described according to the assigment
//-----------------------------------------
import org.junit.jupiter.api.BeforeEach;
import java.util.ArrayList;
import java.util.Scanner;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ComputerTest {
    //Data Cards
    Card Gun=new Card("Gun","Weapon");
    Card Knife=new Card("Knife","Weapon");
    Card Poison=new Card("Poison","Weapon");

    Card Home=new Card("Home","Place");
    Card Work=new Card("Work","Place");
    Card School=new Card("School","Place");

    Card Mike=new Card("Mike","Suspect");
    Card Ali=new Card("Ali","Suspect");
    Card Jass=new Card("Jass","Suspect");
    // Data ArrayList

    ArrayList<Card> Suspect=new ArrayList<Card>(3);
    ArrayList<Card> Place=new ArrayList<Card>(3);
    ArrayList<Card> Weapon=new ArrayList<Card>(3);
    Computer C1=new Computer();
    Computer C2=new Computer();
    Human H=new Human();
    Guess guess1;
    Guess guess2= new Guess(Poison,Jass,School,true);
    //@BeforeEach
    //This method runs before all the tests and initializes all the Cards and lists
     @BeforeEach
     public void start(){
         Suspect.add(Mike);
         Suspect.add(Ali);
         Suspect.add(Jass);
         Place.add(Home);
         Place.add(Work);
         Place.add(School);
         Weapon.add(Poison);
         Weapon.add(Knife);
         Weapon.add(Gun);
         C1.setUp(3,1,Suspect,Place,Weapon);
         C2.setUp(3,2,Suspect,Place,Weapon);
         H.setUp(3,3,Suspect,Place,Weapon);
         guess1= new Guess(Gun,Mike,Home,false);
    }



    @Test
    public void Test1() {
         if(C1.myCards.size()==0){
             assertNull(C1.canAnswer(guess1,H));
         }
    }
    @Test
    public void Test2() {
         //if we have gun in C1 it should output Gun as the CanAnswer
         C1.setCard(Gun);
         assertEquals(C1.canAnswer(guess1,H),Gun);
    }
    @Test
    public void Test3() {
        C1.setCard(Gun);
        C1.setCard(Mike);
        assertTrue(C1.canAnswer(guess1,H)==Gun||C1.canAnswer(guess1,H)==Mike);
    }
    @Test
    public void Test4() {
        C1.setCard(Gun);
        C1.setCard(Mike);
        C1.setCard(Knife);
        C1.setCard(Home);
        assertNotEquals(C1.getGuess(),Gun);
        assertNotEquals(C1.getGuess(),Mike);
        assertNotEquals(C1.getGuess(),Knife);
        assertNotEquals(C1.getGuess(),Home);
    }
    @Test
    public void Test5() {
        C1.setCard(Gun);
        C1.setCard(Mike);
        C1.setCard(Knife);
        C1.setCard(Home);
        C1.setCard(Ali);
        C1.setCard(Work);
        assertTrue(C1.getGuess().getaccusation());
        assertEquals(C1.getGuess().getWeapon(),Poison);
        assertEquals(C1.getGuess().getSuspect(),Jass);
        assertEquals(C1.getGuess().getLocation(),School);
    }
    @Test
    public void Test6() {

    }
    @Test
    public void Test7() {
        H.setCard(Gun);
        H.setCard(Mike);
        H.setCard(Knife);
        H.setCard(Jass);
        H.setCard(Ali);
        H.setCard(School);
        // assert that the input given by Human is either jass or school
        assertFalse((H.canAnswer(guess2, C1).equals(Jass))||H.canAnswer(guess2, C1).equals(School) );
    }
}
