
 //-----------------------------------------
     // NAME		: Jaspreet Singh 
     // STUDENT NUMBER	: 7859706
     // COURSE		: COMP 2150
     // INSTRUCTOR	: Micheal Domaratski
     // ASSIGNMENT	: assignment 4
     // REMARKS: To create a class for object named Node that stores a chart, wieght and two left and right child nodes
//-----------------------------------------------
class Node{
    constructor(){//constructor
        //first argument is char and second argument is wieght
        if(arguments.length==2){
            this.char=arguments[0];
            this.wieght=arguments[1];
            this.left = null;
            this.right = null;
        }else if(arguments.length==4){
            this.char=arguments[0];
            this.wieght=arguments[1];
            this.left = arguments[2];
            this.right = arguments[3];
        }
        else{
            throw new Error("Invalid arguments in Node constructor")
        }
    }
}
module.exports = Node;