// what #includes do we need?
#include "Node.h"

Node* Node::getNext() { 
	return next; 
}

void Node::setNext(Node* next) { 
	this->next = next; 
}

IntItem* Node::getData() {
	return item;
}

void Node::print() { 
	item->print();
}

Node::Node(IntItem* item) {
	this->item = item; 
	this->next = nullptr;
}

Node::Node() {
	this->item = 0; 
	this->next = nullptr;
}
