 //-----------------------------------------
     // NAME		: Jaspreet Singh 
     // STUDENT NUMBER	: 7859706
     // COURSE		: COMP 2150
     // INSTRUCTOR	: Micheal Domaratski
     // ASSIGNMENT	: assignment 4
     // REMARKS: a Test class for Dictionary and hashable objects and test edge cases for them
//-----------------------------------------------
"use strict";
let assert = require('assert');
let Dictionary = require('./Dictionary.js');
let intHash=require('./Hashable.js')

function main() {
    let d= new Dictionary(100);
    let k=new intHash(2);
    test1(d)
    d.put(k,2);
    test2(d)
}
//test 1 checks if the given dictionary is empty
 function test1(d){
     if(d instanceof Dictionary){
        assert(d.isEmpty());
    }
 }
 //test 2 checks if it exactly have 1 element
 function test2(d){
    if(d instanceof Dictionary){
       assert(!d.isEmpty());
       assert(d.contains(k));
   }
}
 main()