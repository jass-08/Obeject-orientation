//-----------------------------------------
// NAME		: Jaspreet Singh
// STUDENT NUMBER	: 7859706
// COURSE		: COMP 2150
// INSTRUCTOR	: Mike Domaratzki
// ASSIGNMENT	: assignment 3
// QUESTION	: question 1
//
// REMARKS: This program stimulates the game whoDunIt via prompts in the console
//You will play against 4 computer  AI
//
//The main class initiates all the cards, creates their arraylists and passes it to the Model class
//-----------------------------------------
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        Card Gun=new Card("Gun","Weapon");
        Card Knife=new Card("Knife","Weapon");
        Card Poison=new Card("Poison","Weapon");
        Card Rope=new Card("Rope","Weapon");
        Card Sword=new Card("Sword","Weapon");
        Card Axe=new Card("Axe","Weapon");

        Card Home=new Card("Home","Place");
        Card Work=new Card("Work","Place");
        Card School=new Card("School","Place");
        Card Lab=new Card("Lab","Place");
        Card Restaurant=new Card("Restaurant","Place");
        Card Kitchen=new Card("Kitchen","Place");

        Card Mike=new Card("Mike","Suspect");
        Card Ali=new Card("Ali","Suspect");
        Card Jass=new Card("Jass","Suspect");
        Card Noman=new Card("Noman","Place");
        Card Steph=new Card("Steph","Place");
        Card Josh=new Card("Josh","Place");
        // Data ArrayList

        ArrayList<Card> Suspect=new ArrayList<Card>();
        ArrayList<Card> Place=new ArrayList<Card>();
        ArrayList<Card> Weapon=new ArrayList<Card>();
        ArrayList<IPlayer> Players=new ArrayList<>();
        Computer C1=new Computer();
        Computer C2=new Computer();
        Computer C3=new Computer();
        Computer C4=new Computer();
        Human H=new Human();

        Players.add(C1);
        Players.add(C2);
        Players.add(C3);
        Players.add(C4);
        Players.add(H);

        Suspect.add(Mike);
        Suspect.add(Ali);
        Suspect.add(Jass);
        Suspect.add(Noman);
        Suspect.add(Steph);
        Suspect.add(Josh);

        Place.add(Home);
        Place.add(Work);
        Place.add(School);
        Place.add(Lab);
        Place.add(Restaurant);
        Place.add(Kitchen);

        Weapon.add(Poison);
        Weapon.add(Knife);
        Weapon.add(Gun);
        Weapon.add(Rope);
        Weapon.add(Sword);
        Weapon.add(Axe);
        Model M=new Model();
        M.gameStartUp(Suspect, Place,Weapon,Players);
    }


}