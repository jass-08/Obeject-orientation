#ifndef LIST_H_
#define LIST_H_

// what includes do we need?
//#include "Node.h"
//#include "IntItem.h"
class Node;
class IntItem;

class List {
private:
	Node* head;
public:
	List();
	void print();
	void insert(IntItem*);
};

#endif /* LIST_H_ */


