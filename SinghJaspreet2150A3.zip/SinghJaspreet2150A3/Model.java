
// CLASS: Model.java
//
// Author: Jaspreet Singh.7859706
//
// REMARKS: The purpose of this class is to initialize all the method and start the game according to the pseudocode
//given
//
//-----------------------------------------
//
import java.util.ArrayList;
import java.util.Collections;

class Model {
    //give all the Players and cards to gameStart
    private ArrayList<Card> AllCards=new ArrayList<Card>();
    private ArrayList<Card> Answers=new ArrayList<Card>(3);
    //------------------------------------------------------
    // gameStartUp()
    //
    // PURPOSE:    This method gets all the input Lists from main class; initializes them and then startup the game
    //according to the pseudocode given
    // PARAMETERS:
    //     four arraylist of Suspects,Weapon,Places and Players
    //------------------------------------------------------
    void  gameStartUp(ArrayList<Card> Suspect, ArrayList<Card> Place, ArrayList<Card> Weapon
            , ArrayList<IPlayer> Players){

        //Print all the Lists
        System.out.println("----------------------------------------");
        System.out.println("Here are the names of all the suspects:");
        for(Card card: Suspect){
            System.out.print(card+", ");
        }
        System.out.println("\n----------------------------------------");
        System.out.println("Here are the names of all the Places:");
        for(Card card: Place){
            System.out.print(card+",");
        }
        System.out.println("\n----------------------------------------");
        System.out.println("Here are the names of all the Weapons:");
        for(Card card: Weapon){
            System.out.print(card+",");
        }
        System.out.println("\n----------------------------------------");
        for(int i=0;i<Players.size();i++){
            Players.get(i).setUp(Players.size(),i,Suspect,Place,Weapon);//sets up the player and assign the indexes
            // Printout your index
            if(Players.get(i) instanceof Human){
                System.out.println("\nYou are seated on number: "+i);
            }
        }

        //Save one cards from each list as Answer
        //Shuffle first
        Collections.shuffle(Suspect);
        Collections.shuffle(Place);
        Collections.shuffle(Weapon);
        Answers.add(Weapon.get(0));
        Weapon.remove(0);
        Answers.add(Suspect.get(0));
        Suspect.remove(0);
        Answers.add(Place.get(0));
        Place.remove(0);
        //Also Store the Answers as a guess to comapare later
        Guess key=new Guess(Answers.get(0),Answers.get(1),Answers.get(2),false);
        //this will add all the remaining cards to the allCards list
        AllCards.addAll(Suspect);
        AllCards.addAll(Place);
        AllCards.addAll(Weapon);
        //Now shuffle it
        Collections.shuffle(AllCards);
        //Now distribute
        System.out.println("Being dealt a card:");
        for(int i=0;i<AllCards.size();i++){
               Players.get(i%Players.size()).setCard(AllCards.get(i));//distribute the ith card to i%nth player
            if(Players.get(i%Players.size()) instanceof Human){
                System.out.println("You received the card :<"+AllCards.get(i)+"> ");
            }
         }
        //Now do the game
        Guess ActiveGuess=new Guess();
        int i=0;
//        ActiveGuess=Players.get(i).getGuess();
        while(!ActiveGuess.equals(key)){//They should be in order weapon,suspect and then location
            System.out.println("====================================");
            System.out.println("Current turn: <"+i+">");
            IPlayer currPlayer=Players.get(i%Players.size());
            ActiveGuess=currPlayer.getGuess();
            if(ActiveGuess.getaccusation()){
                //If all three cards match
                if(ActiveGuess.getWeapon().equals(Answers.get(0)) && ActiveGuess.getSuspect().equals(Answers.get(1))
                        && ActiveGuess.getLocation().equals(Answers.get(2))){

                    break;
                }else{
                    System.out.println("Wrong Accusation; The player <"+i+"> is out of the game");
                }
            }else{
                for(int j=1;j< Players.size();j++){
                    IPlayer nextPlayer=Players.get((i+j)%Players.size());
                    System.out.println("Asking Player: <"+(i+j)+"> ");
                    Card result=nextPlayer.canAnswer(ActiveGuess,currPlayer);
                    if(result!=null){
                        currPlayer.setCard(result);
                        System.out.println("The Player: <"+currPlayer.getIndex()+"> got the answer from Player: <"+ nextPlayer.getIndex()+"> ");
                    }else{
                        System.out.println("The Player: <"+currPlayer.getIndex()+"> can't get the answer from Player: <"+ nextPlayer.getIndex()+"> ");
                    }
                }
            }
            i=(i+1)%Players.size();
        }
        System.out.println("The Winner is: "+Players.get(i));
    }
}
