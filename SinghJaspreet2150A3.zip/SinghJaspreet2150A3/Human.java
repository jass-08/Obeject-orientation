// CLASS: Human.java
//
// Author: Jaspreet Singh,7859706
//
// REMARKS: The purpose of this class is to implement Iplayer.java in such a way that it asks for human input as the
// game progress
//
//-----------------------------------------
import java.util.ArrayList;
import java.util.Scanner;

public class Human implements IPlayer {
    private int totalPlayer;
    private int myIndex;
    private ArrayList<Card> Suspects;
    private ArrayList<Card> Places;
    private ArrayList<Card> Weapon;
    private ArrayList<Card> myCards=new ArrayList<Card>();
    public void setUp(int numPlayers, int index, ArrayList<Card> ppl, ArrayList<Card> places, ArrayList<Card> weapons) {
        totalPlayer=numPlayers;
        myIndex=index;
        Suspects=ppl;
        Places=places;
        Weapon=weapons;
    }


    public void setCard(Card c) {
        myCards.add(c);
    }

    public int getIndex() {
        return myIndex;
    }

    //------------------------------------------------------
    // canAnswer
    //
    // PURPOSE:    This method ask if the current Human Player if it has any of the cards from
    // Guess g by Player ip through prompts
    // PARAMETERS:
    //    The guess g made by IPlayer ip
    // Returns: returns the Card if the current player has it or null otherwise
    //------------------------------------------------------
    public Card canAnswer(Guess g, IPlayer ip) {
        Card result=null;
        System.out.println("--------Its your Turn--------");
        System.out.println("The cards you have are:");
        for (Card card: myCards ) {
            System.out.println(card);
        }
        Scanner reader=new Scanner(System.in);
        System.out.println("Do you have any card from the above guess?[Y/N]");
        String c=reader.next();
        if(c.equals("Y")){
            System.out.println("Enter the Name of the Card you have");
            String Value=reader.next();
            System.out.println("Enter type of the Card you have [Weapon/Suspect/Location]");
            String type=reader.next();
            result=new Card(Value,type);
            //ip.setCard(result);//he will
        }
        return result;
    }

    //------------------------------------------------------
    // getGuess
    //
    // PURPOSE: This method returns a appropriate guess made by the Human given its own cards and last guesses through prompts
    // Returns: Guess
    //------------------------------------------------------
    public Guess getGuess() {
        boolean acc=false;
        Card Person;
        Card Location;
        Card arm;
        System.out.println("--------Its your Turn to Suggest--------");
        System.out.println("Is this an accusation [Y/N]");
        Scanner reader = new Scanner(System.in);
        String c = reader.next();
        if(c.equals("Y")){
            acc=true;
        }
        System.out.println("Which person do you want to suggest?");
        reader = new Scanner(System.in);
        String p = reader.next();
        Person=new Card(p,"Suspect");
        if(Suspects.contains(Person)){
            System.out.println("Invalid Input");
            System.out.println("Which person do you want to suggest? enter one of the following only:");
            for (Card Suspect : Suspects) {
                System.out.println(Suspect);
            }
            reader = new Scanner(System.in);
             p = reader.next();
            Person=new Card(p,"Suspect");
        }

        System.out.println(" Which location do you want to suggest?");
        reader = new Scanner(System.in);
        String l = reader.next();
        Location=new Card(l,"Location");
        if(Places.contains(Location)){
            System.out.println("Invalid Input");
            System.out.println("Which location do you want to suggest? enter one of the following only:");
            for (Card Suspect : Places) {
                System.out.println(Suspect);
            }
            reader = new Scanner(System.in);
            l = reader.next();
            Location=new Card(l,"Location");
        }

        System.out.println("Which weapon do you want to suggest?");
        reader = new Scanner(System.in);
        String w = reader.next();
        arm=new Card(p,"Weapon");
        if(Weapon.contains(arm)){
            System.out.println("Invalid Input");
            System.out.println("Which weapon do you want to suggest? enter one of the following only:");
            for (Card Suspect : Weapon) {
                System.out.println(Suspect);
            }
            reader = new Scanner(System.in);
            w = reader.next();
            arm=new Card(p,"Suspect");
        }
        //receiveInfo();
        //reader.close();
        Guess g =new Guess(arm,Person,Location,acc);
        System.out.println("The Human Player guessed: "+g);
        return  g;
    }


    public void receiveInfo(IPlayer ip, Card c) {
        if(ip!=null&&c!=null){
            setCard(c);
        }
    }
}
