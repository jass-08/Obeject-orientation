// CLASS: Computer.java
//
// Author: Jaspreet Singh,7859706
//
// REMARKS: The purpose of this class is to implement Iplayer.java in such a way that it acts like the Computer AI as
//the game progress
//
//-----------------------------------------
import java.util.ArrayList;
import java.util.Random;

public class Computer implements IPlayer {
    private int totalPlayer;
    private int myIndex;
    private ArrayList<Card> Suspects;
    private ArrayList<Card> Places;
    private ArrayList<Card> Weapon;
    public ArrayList<Card> myCards=new ArrayList<Card>();

    public void setUp(int numPlayers, int index, ArrayList<Card> ppl, ArrayList<Card> places, ArrayList<Card> weapons) {
        totalPlayer=numPlayers;
        myIndex=index;
        Suspects=ppl;
        Places=places;
        Weapon=weapons;
    }


    public void setCard(Card c) {
        myCards.add(c);
    }


    public int getIndex() {
        return  myIndex;
    }

//------------------------------------------------------
    // canAnswer
    //
    // PURPOSE:    This method ask if the current Player has any of the cards from
    // Guess g by Player ip
    // PARAMETERS:
    //    The guess g made by IPlayer ip
    // Returns: returns the Card if the current player has it or null otherwise
    //------------------------------------------------------
    public Card canAnswer(Guess g, IPlayer ip) {
        Card result=null;
        for(int i=0;i<myCards.size();i++) {//for all cards in the hand
            for(int j=0;j<3;j++){//for all 3 cards in guess
                if(g.getGuess()[j]==myCards.get(i)){//if it matches
                    result=myCards.get(i);//store the card and return
                }
            }
        }
        return result;
    }
//------------------------------------------------------
    // getGuess
    //
    // PURPOSE: This method returns a appropriate guess made by the computer given its own cards and last guesses
    // Returns: Guess
    //------------------------------------------------------
    public Guess getGuess() {
        Random r=new Random();
        int WIndex = r.nextInt(Weapon.size());
        int PIndex=r.nextInt(Places.size());
        int SIndex=r.nextInt(Suspects.size());
        int TotalCards=Weapon.size()+Places.size()+Suspects.size();
        boolean acc=false;
        Guess g;
        if((TotalCards-myCards.size())>3) {
            acc=false;
            if (myCards.contains(Weapon.get(WIndex))) {//if it contains the card the player already have
                r = new Random();//change it
                WIndex = r.nextInt(Weapon.size());
            }if (myCards.contains(Suspects.get(SIndex))) {//if it contains the card the player already have
                r = new Random();//change it
                SIndex = r.nextInt(Suspects.size());
            }
            if (myCards.contains(Places.get(PIndex))) {//if it contains the card the player already have
                r = new Random();//change it
                PIndex = r.nextInt(Places.size());
            }

            g =new Guess(Weapon.get(WIndex),Suspects.get(SIndex),Places.get(PIndex),acc);
        }else if ((TotalCards-myCards.size())==3){
            acc=true;
            Card W=new Card("","");//create empty cards
            Card S=new Card("","");
            Card P=new Card("","");
            for (Card card : Weapon) {
                if (!myCards.contains(card)) {
                    W=card;
                }
            }
            for (Card card : Suspects) {
                if (!myCards.contains(card)) {
                    S=card;
                }
            }
            for (Card card : Places) {
                if (!myCards.contains(card)) {
                    P=card;
                }
            }
            g=new Guess(W,S,P,acc);
        }else{
            g=new Guess(myCards.get(0),myCards.get(1),myCards.get(2),acc);
        }
        System.out.println("The Computer Player "+ myIndex+" guessed: "+g);
        return g;
    }


    public void receiveInfo(IPlayer ip, Card c) {
        if(ip!=null&&c!=null){
            setCard(c);
        }
    }
}
