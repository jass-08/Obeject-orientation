

#include "ListItem.h"

//#include <iostream>
//using namespace std;
//
//void ListItem::print() {
//	cout << "please don't create listitems." << endl;
//}

void ListItem::dostuff() { }
