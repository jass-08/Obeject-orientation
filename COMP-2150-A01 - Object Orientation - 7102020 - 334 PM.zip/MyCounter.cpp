#include "MyCounter.h"

// * this code is needed to do output.
#include <iostream>
using namespace std;
// * end output code


void MyCounter::increment() {
        value+=1;
}

void MyCounter::reset() {
        value = 0;
}

void MyCounter::print() {
        cout << value << endl;
}

MyCounter::MyCounter() {
        value = 0;
}

MyCounter::MyCounter(int v) {
        value = v;
}

bool MyCounter::equals( MyCounter other) {
        return value == other.value;
}

int MyCounter::getValue() {
        return value;
}
