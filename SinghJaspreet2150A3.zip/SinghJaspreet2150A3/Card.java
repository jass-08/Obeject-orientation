// CLASS: Card.java
//
// Author: Jaspreet Singh, 7859706
//
// REMARKS: The purpose of this class is to create Class Card that stores two attributes
// Value and type
//It is used to create an object named card
//-----------------------------------------

public class Card {
    private String value;
    private String type;
    public Card(String Value, String Type){
        value=Value;
        type=Type;
    }

    public String toString(){
        return  value;
    }

    public String getType() {
        return type;
    }

    public String getValue() {
        return value;
    }
}
