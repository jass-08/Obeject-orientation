// CLASS: Guess.java
//
// Author: Jaspreet Singh,7859706
//
// REMARKS: The purpose of this class is to create a object named guess that stores 3 cards and on boolean if its accusation
//
//-----------------------------------------
public class Guess {
    private Card[] guess=new Card[3];
    private boolean accusation;
    public Guess(){}//Empty contructor
    public Guess(Card Weapon, Card Suspect, Card Location, boolean acc){
        guess[0]=Weapon;
        guess[1]=Suspect;
        guess[2]=Location;
        accusation=acc;
    }
    public String toString(){
        if(!getaccusation()){
        return "Suggestion: <"+guess[1]+"> in <"+guess[2]+"> with the <"+guess[0]+">." ;
        }else{
            return "Accusation<"+guess[1]+"> in <"+guess[2]+"> with the <"+guess[0]+">.";
        }
    }

    public Card[] getGuess() {
        return guess;
    }

    public Card getWeapon(){
        return guess[0];
    }

    public Card getSuspect(){
        return guess[1];
    }

    public Card getLocation(){
        return guess[2];
    }

    public boolean getaccusation(){
        return accusation;

    }
}
