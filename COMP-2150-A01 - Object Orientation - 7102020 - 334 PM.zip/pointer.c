#include <stdlib.h>
#include <stdio.h>

int main () {

	int* x = (int*) malloc (sizeof(int));
	*x = 9001;
	int* y = x;
	(*y)++;
	printf("%d\n", *x);
	free(x);
	

	return 0;
}



