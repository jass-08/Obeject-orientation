
#ifndef INTITEM_H_
#define INTITEM_H_

#include "ListItem.h"

class IntItem : public ListItem {
private:
	int data;
public:
	IntItem();
	IntItem(int i);
	void print();
};

#endif


