


class MyCounter {
private:
	int value;
public:
	MyCounter();
	MyCounter(int );
	void increment();
	void reset();
	int getValue();
	bool equals (MyCounter );
	void print();
};



