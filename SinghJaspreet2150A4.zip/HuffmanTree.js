 //-----------------------------------------
     // NAME		: Jaspreet Singh 
     // STUDENT NUMBER	: 7859706
     // COURSE		: COMP 2150
     // INSTRUCTOR	: Micheal Domaratski
     // ASSIGNMENT	: assignment 4
     // REMARKS: To create a class for object named Huffman Tree that is 
     // similar to binary tress but helps us store the data for Huffman Encoding
//----------------------------------------------
"use strict";
let Node=require('./Node.js')
class Tree{
    constructor(){
        if(arguments.length==2){
            this.node=new Node(arguments[0],arguments[1]);//argument
            // this.top=this.node;
        }
        else
            throw new Error("Invalid arguments in Tree constructor")
    }
    //add method must have two arguments left and right tree child respectively
    add(leftTree,rightTree){
        if(leftTree instanceof Tree && rightTree instanceof Tree){
            this.left=leftTree;
            this.right=rightTree;
            this.node.wieght=leftTree.node.wieght+rightTree.node.wieght;
        }else{
            throw new Error("Invalid arguments in add method")
        }
    }
    //------------------------------------------------------
     //compareTo(tree)
     // PURPOSE://this function compares the given tree with the 
     // our tree and finds the lowest one
     // PARAMETERS:
     //    an array of type tree
     // Returns: +1/-1 or 0 according to the trees given 
     //------------------------------------------------------
    compareTo(tree){
        result=0;
        if(tree instanceof Tree){
            if(this.Tree.node.wieght<tree.node.wieght){
                result=-1;
            }else if(this.Tree.wieght>tree.wieght){
                result=+1;
            }else if(this.Tree.wieght==tree.wieght){
                let c1=findLowestChar(this.Tree);
                let c2=findLowestChar(tree);
                if(c1<c2){
                    result=-1;
                }else if(c1>c2){
                    result=1;
                }
            }
        }else{
            throw new Error("Invalid arguments in compareTo method")
        }
    }
    //This method traverse through all the tree and find the lowest char
    //using recursion
    findLowestChar(tree){
        lowestChar="";
        curr= tree.top;
        //using preorder traversal
        if(curr!=null){
            if(curr.char<lowestChar){
                lowestChar=curr.char;
            }
        }
        findLowestChar(tree.left);
        findLowestChar(tree.right);
    }
}


module.exports= Tree;