public class Main {

    public static void main(String[] args) {

        List list1 = new List();
        List list2 = new List();

        list1.add(new IntItem(3));
        list1.add(new IntItem(5));
        list1.add(new CharItem('a'));

        list1.print(); // Output [a 5 3]
        
        list2.add(new List());
        list2.add(list1);
        list2.add(new IntItem(33));
        list2.print(); // output [33 [a 5 3]]

    }
}


