#include "counter.h" 

int main() {

	// declare a MyCounter and use it....
	
	MyCounter* mc = new MyCounter;
	mc->increment();
	mc->increment();
	mc->print();
	
	return 0;
}
